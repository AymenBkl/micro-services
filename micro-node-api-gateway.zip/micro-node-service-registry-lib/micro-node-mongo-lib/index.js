/**
 * Created by domenicovacchiano on 07/07/16.
 */
'use strict';

module.exports = require('./lib/micro-node-mongo-lib');
